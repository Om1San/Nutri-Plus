#include <iostream>
#include <time.h>
#include <cstdlib>
using namespace std;

int main(){   int a,b,c=1;   srand(time(NULL));
    
cout<<"Bienvenido al juego de Piedra, Papel y tijeras"<<endl;

do
{
cout<<"Elige una opcion: [Piedra = 1] [Papel = 2] [Tijera = 3]";
cin>>a;
b=1+rand()%(3);

switch(a){
case 1://piedra
if(b==1){
    cout<<"Piedra"<<endl;
    cout<<"empate"<<endl;
}
else if(b==2){
    cout<<"Papel"<<endl;
    cout<<"perdiste"<<endl;
}
else if(b==3){
    cout<<"Tijera"<<endl;
    cout<<"ganaste"<<endl;
}
else{
    cout<<"??"<<endl;
}
break;

case 2:
if(b==1){
    cout<<"Piedra"<<endl;
    cout<<"ganaste"<<endl;
}
else if(b==2){
    cout<<"Papel"<<endl;
    cout<<"empate"<<endl;
}
else if(b==3){
    cout<<"Tijera"<<endl;
    cout<<"perdiste"<<endl;
}
else{
    cout<<"??"<<endl;
}
break;

case 3:
if(b==1){
    cout<<"Piedra"<<endl;
    cout<<"perdiste"<<endl;
}
else if(b==2){
    cout<<"Papel"<<endl;
    cout<<"ganaste"<<endl;
}
else if(b==3){
    cout<<"Tijera"<<endl;
    cout<<"empate"<<endl;
}
else{
    cout<<"??"<<endl;
}
break;

default:
cout<<"wrrooong"<<endl;
break;

}
cout<<"quieres seguir jugando? Si=1 No=2"<<endl;
cin>>c;
}while(c==1);
return 0;
}
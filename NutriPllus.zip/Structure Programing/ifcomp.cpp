#include <iostream>
using namespace std;

int main(){
string a;//La variable a tipo string almacena la respuesta de "Tienes un Bachillerato?"
string b;//La variable b tipo string almacena la respuesta de "Tienes experiencia?"

cout<<"Programa Solicitud de Trabajo"<<endl;
cout<<"Tienes un Bachillerato? (Si/No)"<<endl;
cin>>a;
cout<<"Tienes experiencia? (Si/No)"<<endl;
cin>>b;

if (a=="Si"&& b=="Si" ){//este if determina si estas contratado si la variable a y b son "Si"
cout<<"Muy bien estas contratado"<<endl;
}
else if(a=="No"&& b=="No"){//este if determina si no estas contratado si la variable a y b son "No"
    cout<<"Lo siento no estas contratado"<<endl;
}
else{cout<<"Te estaremos contactando luego"<<endl;}//determina si las contestaciones no son iguales

}
#include <iostream>
using namespace std;

int main(){ 

    string Nombre;//Se refiere al nombre de la persona en una variable tipo string
    char G;//Se refiere a el genero de la persona en una variable de una sola letra (M para masculino o F para femenino)

        cout<<"-[[Formulario de Usuario]]-\n\n"<<"Nombre : ";
        cin>>Nombre;
        cout<<"Genero (M o F) : ";
        cin>>G;
        cout<<endl;
        cout<<"Tu nombre es : "<<Nombre<<endl<<"Tu Sexo es : "<<G;
        cout<<endl;
        system("pause");
return 0;
}

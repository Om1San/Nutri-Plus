﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IDLabel As System.Windows.Forms.Label
        Dim EjercicioLabel As System.Windows.Forms.Label
        Dim Calorias_QuemadasLabel As System.Windows.Forms.Label
        Dim RepsLabel As System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.NutriBaseDataSet = New NutriPllus.NutriBaseDataSet()
        Me.EjerciciosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EjerciciosTableAdapter = New NutriPllus.NutriBaseDataSetTableAdapters.EjerciciosTableAdapter()
        Me.TableAdapterManager = New NutriPllus.NutriBaseDataSetTableAdapters.TableAdapterManager()
        Me.EjerciciosDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IDTextBox = New System.Windows.Forms.TextBox()
        Me.EjercicioTextBox = New System.Windows.Forms.TextBox()
        Me.Calorias_QuemadasTextBox = New System.Windows.Forms.TextBox()
        Me.RepsTextBox = New System.Windows.Forms.TextBox()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        IDLabel = New System.Windows.Forms.Label()
        EjercicioLabel = New System.Windows.Forms.Label()
        Calorias_QuemadasLabel = New System.Windows.Forms.Label()
        RepsLabel = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        CType(Me.NutriBaseDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EjerciciosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EjerciciosDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IDLabel
        '
        IDLabel.AutoSize = True
        IDLabel.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        IDLabel.Location = New System.Drawing.Point(759, 498)
        IDLabel.Name = "IDLabel"
        IDLabel.Size = New System.Drawing.Size(31, 19)
        IDLabel.TabIndex = 40
        IDLabel.Text = "ID:"
        '
        'EjercicioLabel
        '
        EjercicioLabel.AutoSize = True
        EjercicioLabel.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EjercicioLabel.Location = New System.Drawing.Point(833, 498)
        EjercicioLabel.Name = "EjercicioLabel"
        EjercicioLabel.Size = New System.Drawing.Size(78, 19)
        EjercicioLabel.TabIndex = 42
        EjercicioLabel.Text = "Ejercicio:"
        '
        'Calorias_QuemadasLabel
        '
        Calorias_QuemadasLabel.AutoSize = True
        Calorias_QuemadasLabel.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Calorias_QuemadasLabel.Location = New System.Drawing.Point(957, 498)
        Calorias_QuemadasLabel.Name = "Calorias_QuemadasLabel"
        Calorias_QuemadasLabel.Size = New System.Drawing.Size(71, 19)
        Calorias_QuemadasLabel.TabIndex = 44
        Calorias_QuemadasLabel.Text = "Calorias:"
        '
        'RepsLabel
        '
        RepsLabel.AutoSize = True
        RepsLabel.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        RepsLabel.Location = New System.Drawing.Point(1068, 498)
        RepsLabel.Name = "RepsLabel"
        RepsLabel.Size = New System.Drawing.Size(48, 19)
        RepsLabel.TabIndex = 46
        RepsLabel.Text = "Reps:"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.PaleGreen
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Button6)
        Me.Panel1.Controls.Add(Me.Button8)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Button5)
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Location = New System.Drawing.Point(-42, -16)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(347, 588)
        Me.Panel1.TabIndex = 27
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(54, 328)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(272, 65)
        Me.Button6.TabIndex = 28
        Me.Button6.Text = "Pronostico"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(54, 475)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(157, 78)
        Me.Button8.TabIndex = 8
        Me.Button8.Text = "Comidas"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.NutriPllus.My.Resources.Resources.calories_calculator_2316949
        Me.PictureBox1.Location = New System.Drawing.Point(54, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(91, 81)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(147, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(189, 23)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Contador de Calorias"
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(217, 475)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(105, 78)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "Salir"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(54, 399)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(271, 65)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "Tienda"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(54, 257)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(272, 65)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Recoleccion de Datos"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(54, 186)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(272, 65)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Ejercicios"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(54, 115)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(272, 65)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Calorias"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.LightCoral
        Me.Panel5.Controls.Add(Me.Label19)
        Me.Panel5.Location = New System.Drawing.Point(-38, -19)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1263, 83)
        Me.Panel5.TabIndex = 28
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(358, 42)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(92, 22)
        Me.Label19.TabIndex = 16
        Me.Label19.Text = "Ejercicios"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(405, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(240, 22)
        Me.Label2.TabIndex = 39
        Me.Label2.Text = "Añade ejercicios a tu listado"
        '
        'NutriBaseDataSet
        '
        Me.NutriBaseDataSet.DataSetName = "NutriBaseDataSet"
        Me.NutriBaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'EjerciciosBindingSource
        '
        Me.EjerciciosBindingSource.DataMember = "Ejercicios"
        Me.EjerciciosBindingSource.DataSource = Me.NutriBaseDataSet
        '
        'EjerciciosTableAdapter
        '
        Me.EjerciciosTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ComidasTableAdapter = Nothing
        Me.TableAdapterManager.EjerciciosTableAdapter = Me.EjerciciosTableAdapter
        Me.TableAdapterManager.PronosticoTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = NutriPllus.NutriBaseDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.UsuarioTableAdapter = Nothing
        '
        'EjerciciosDataGridView
        '
        Me.EjerciciosDataGridView.AutoGenerateColumns = False
        Me.EjerciciosDataGridView.BackgroundColor = System.Drawing.SystemColors.ActiveCaption
        Me.EjerciciosDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.EjerciciosDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4})
        Me.EjerciciosDataGridView.DataSource = Me.EjerciciosBindingSource
        Me.EjerciciosDataGridView.Location = New System.Drawing.Point(409, 125)
        Me.EjerciciosDataGridView.Name = "EjerciciosDataGridView"
        Me.EjerciciosDataGridView.RowHeadersWidth = 51
        Me.EjerciciosDataGridView.RowTemplate.Height = 24
        Me.EjerciciosDataGridView.Size = New System.Drawing.Size(695, 323)
        Me.EjerciciosDataGridView.TabIndex = 40
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "ID"
        Me.DataGridViewTextBoxColumn1.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 125
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Ejercicio"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Ejercicio"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 125
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Calorias_Quemadas"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Calorias_Quemadas"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 125
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "Reps"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Reps"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 125
        '
        'IDTextBox
        '
        Me.IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EjerciciosBindingSource, "ID", True))
        Me.IDTextBox.Location = New System.Drawing.Point(747, 473)
        Me.IDTextBox.Name = "IDTextBox"
        Me.IDTextBox.Size = New System.Drawing.Size(56, 22)
        Me.IDTextBox.TabIndex = 41
        '
        'EjercicioTextBox
        '
        Me.EjercicioTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EjerciciosBindingSource, "Ejercicio", True))
        Me.EjercicioTextBox.Location = New System.Drawing.Point(821, 473)
        Me.EjercicioTextBox.Name = "EjercicioTextBox"
        Me.EjercicioTextBox.Size = New System.Drawing.Size(114, 22)
        Me.EjercicioTextBox.TabIndex = 43
        '
        'Calorias_QuemadasTextBox
        '
        Me.Calorias_QuemadasTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EjerciciosBindingSource, "Calorias_Quemadas", True))
        Me.Calorias_QuemadasTextBox.Location = New System.Drawing.Point(951, 473)
        Me.Calorias_QuemadasTextBox.Name = "Calorias_QuemadasTextBox"
        Me.Calorias_QuemadasTextBox.Size = New System.Drawing.Size(86, 22)
        Me.Calorias_QuemadasTextBox.TabIndex = 45
        '
        'RepsTextBox
        '
        Me.RepsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EjerciciosBindingSource, "Reps", True))
        Me.RepsTextBox.Location = New System.Drawing.Point(1063, 473)
        Me.RepsTextBox.Name = "RepsTextBox"
        Me.RepsTextBox.Size = New System.Drawing.Size(53, 22)
        Me.RepsTextBox.TabIndex = 47
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(406, 468)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(104, 49)
        Me.Button10.TabIndex = 50
        Me.Button10.Text = "Borrar"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(628, 468)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(104, 49)
        Me.Button9.TabIndex = 49
        Me.Button9.Text = "Guardar"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(516, 468)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(106, 49)
        Me.Button7.TabIndex = 48
        Me.Button7.Text = "Nuevo"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(240, 83)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 23)
        Me.Label3.TabIndex = 51
        Me.Label3.Text = "Nutri-Plus"
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1182, 553)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(IDLabel)
        Me.Controls.Add(Me.IDTextBox)
        Me.Controls.Add(EjercicioLabel)
        Me.Controls.Add(Me.EjercicioTextBox)
        Me.Controls.Add(Calorias_QuemadasLabel)
        Me.Controls.Add(Me.Calorias_QuemadasTextBox)
        Me.Controls.Add(RepsLabel)
        Me.Controls.Add(Me.RepsTextBox)
        Me.Controls.Add(Me.EjerciciosDataGridView)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel5)
        Me.Name = "Form3"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form3"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        CType(Me.NutriBaseDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EjerciciosBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EjerciciosDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button6 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label19 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents NutriBaseDataSet As NutriBaseDataSet
    Friend WithEvents EjerciciosBindingSource As BindingSource
    Friend WithEvents EjerciciosTableAdapter As NutriBaseDataSetTableAdapters.EjerciciosTableAdapter
    Friend WithEvents TableAdapterManager As NutriBaseDataSetTableAdapters.TableAdapterManager
    Friend WithEvents EjerciciosDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents IDTextBox As TextBox
    Friend WithEvents EjercicioTextBox As TextBox
    Friend WithEvents Calorias_QuemadasTextBox As TextBox
    Friend WithEvents RepsTextBox As TextBox
    Friend WithEvents Button10 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Label3 As Label
End Class

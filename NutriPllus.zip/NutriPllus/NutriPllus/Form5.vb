﻿Public Class Form5
    Dim cal_Q, cal_C, cal_Con, cal_Que, cal_Tot As Integer

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        End
    End Sub

    Private Sub ComidasBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.ComidasBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.NutriBaseDataSet)

    End Sub

    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'NutriBaseDataSet.Pronostico' table. You can move, or remove it, as needed.
        Me.PronosticoTableAdapter.Fill(Me.NutriBaseDataSet.Pronostico)
        'TODO: This line of code loads data into the 'NutriBaseDataSet.Usuario' table. You can move, or remove it, as needed.
        Me.UsuarioTableAdapter.Fill(Me.NutriBaseDataSet.Usuario)
        'TODO: This line of code loads data into the 'NutriBaseDataSet.Usuario' table. You can move, or remove it, as needed.
        Me.UsuarioTableAdapter.Fill(Me.NutriBaseDataSet.Usuario)
        'TODO: This line of code loads data into the 'NutriBaseDataSet.Ejercicios' table. You can move, or remove it, as needed.
        Me.EjerciciosTableAdapter.Fill(Me.NutriBaseDataSet.Ejercicios)
        'TODO: This line of code loads data into the 'NutriBaseDataSet.Comidas' table. You can move, or remove it, as needed.
        Me.ComidasTableAdapter.Fill(Me.NutriBaseDataSet.Comidas)
        Dim cal_Dia As Integer
        Dim sexo As String = SexoTextBox.Text
        Dim peso As Double = PesoTextBox.Text
        Dim altura As Double = AlturaTextBox.Text
        Dim edad As Integer = EdadTextBox.Text
        Dim peso_M As Integer = Peso_MTextBox.Text
        If sexo = "M" Then
            cal_Dia = 66 + (13.7 * peso) + (5 * altura) - (6.75 * edad)
            Label14.Text = cal_Dia
        ElseIf sexo = "F" Then
            cal_Dia = 65 + (9.6 * peso) + (1.8 * altura) - (4.7 * edad)
            Label14.Text = cal_Dia
        Else
            Label14.Text = "Error"

        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim form3 As New Form3()
        form3.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim form4 As New Form4()
        form4.Show()
        Me.Hide()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Dim form2 As New Form2()
        form2.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        System.Diagnostics.Process.Start("http://www.gnc.com")
    End Sub

    Private Sub ComidasDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles ComidasDataGridView.CellContentClick
        If e.ColumnIndex >= 0 AndAlso e.RowIndex >= 0 Then

            cal_C = ComidasDataGridView.Rows(e.RowIndex).Cells("DataGridViewTextBoxColumn3").Value.ToString()


            Label3.Text = cal_C
        Else
            Label3.Text = "error"
        End If
    End Sub

    Private Sub EjerciciosDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles EjerciciosDataGridView.CellContentClick
        If e.ColumnIndex >= 0 AndAlso e.RowIndex >= 0 Then

            cal_Q = EjerciciosDataGridView.Rows(e.RowIndex).Cells("DataGridViewTextBoxColumn6").Value.ToString()

            Label5.Text = cal_Q
        Else
            Label5.Text = "error"
        End If
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        'cal_C = Calorias consumidas. cal_Con = Suma de las calorias consumidas.'
        cal_Con = cal_C + cal_Con
        Label9.Text = cal_Con
        cal_Tot = cal_C + cal_Tot
        Label13.Text = cal_Tot
        cal_C = 0
    End Sub
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        'cal_Q = Calorias quemadas. cal_Que = Suma de las calorias quemadas'
        cal_Que = cal_Q + cal_Que
        Label11.Text = cal_Que
        cal_Tot = cal_Tot - cal_Q
        Label13.Text = cal_Tot
        cal_Q = 0
    End Sub
End Class
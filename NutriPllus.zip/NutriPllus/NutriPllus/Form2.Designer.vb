﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IDLabel As System.Windows.Forms.Label
        Dim ComidaLabel As System.Windows.Forms.Label
        Dim CaloriasLabel As System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.NutriBaseDataSet = New NutriPllus.NutriBaseDataSet()
        Me.ComidasBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ComidasTableAdapter = New NutriPllus.NutriBaseDataSetTableAdapters.ComidasTableAdapter()
        Me.TableAdapterManager = New NutriPllus.NutriBaseDataSetTableAdapters.TableAdapterManager()
        Me.ComidasDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IDTextBox = New System.Windows.Forms.TextBox()
        Me.ComidaTextBox = New System.Windows.Forms.TextBox()
        Me.CaloriasTextBox = New System.Windows.Forms.TextBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        IDLabel = New System.Windows.Forms.Label()
        ComidaLabel = New System.Windows.Forms.Label()
        CaloriasLabel = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        CType(Me.NutriBaseDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ComidasBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ComidasDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IDLabel
        '
        IDLabel.AutoSize = True
        IDLabel.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        IDLabel.Location = New System.Drawing.Point(797, 499)
        IDLabel.Name = "IDLabel"
        IDLabel.Size = New System.Drawing.Size(31, 19)
        IDLabel.TabIndex = 29
        IDLabel.Text = "ID:"
        '
        'ComidaLabel
        '
        ComidaLabel.AutoSize = True
        ComidaLabel.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ComidaLabel.Location = New System.Drawing.Point(902, 499)
        ComidaLabel.Name = "ComidaLabel"
        ComidaLabel.Size = New System.Drawing.Size(67, 19)
        ComidaLabel.TabIndex = 31
        ComidaLabel.Text = "Comida:"
        '
        'CaloriasLabel
        '
        CaloriasLabel.AutoSize = True
        CaloriasLabel.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        CaloriasLabel.Location = New System.Drawing.Point(1021, 499)
        CaloriasLabel.Name = "CaloriasLabel"
        CaloriasLabel.Size = New System.Drawing.Size(71, 19)
        CaloriasLabel.TabIndex = 33
        CaloriasLabel.Text = "Calorias:"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.PaleGreen
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Button6)
        Me.Panel1.Controls.Add(Me.Button8)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Button5)
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Location = New System.Drawing.Point(-42, -16)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(347, 588)
        Me.Panel1.TabIndex = 27
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(54, 328)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(272, 65)
        Me.Button6.TabIndex = 28
        Me.Button6.Text = "Pronostico"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(54, 475)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(157, 78)
        Me.Button8.TabIndex = 8
        Me.Button8.Text = "Comidas"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.NutriPllus.My.Resources.Resources.calories_calculator_2316949
        Me.PictureBox1.Location = New System.Drawing.Point(54, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(91, 81)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(147, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(189, 23)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Contador de Calorias"
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(217, 475)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(105, 78)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "Salir"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(54, 399)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(271, 65)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "Tienda"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(54, 257)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(272, 65)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Recoleccion de Datos"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(54, 186)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(272, 65)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Ejercicios"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(54, 115)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(272, 65)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Calorias"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.LightCoral
        Me.Panel5.Controls.Add(Me.Label19)
        Me.Panel5.Location = New System.Drawing.Point(-38, -19)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1263, 83)
        Me.Panel5.TabIndex = 28
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(359, 41)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(82, 22)
        Me.Label19.TabIndex = 16
        Me.Label19.Text = "Comidas"
        '
        'NutriBaseDataSet
        '
        Me.NutriBaseDataSet.DataSetName = "NutriBaseDataSet"
        Me.NutriBaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ComidasBindingSource
        '
        Me.ComidasBindingSource.DataMember = "Comidas"
        Me.ComidasBindingSource.DataSource = Me.NutriBaseDataSet
        '
        'ComidasTableAdapter
        '
        Me.ComidasTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ComidasTableAdapter = Me.ComidasTableAdapter
        Me.TableAdapterManager.EjerciciosTableAdapter = Nothing
        Me.TableAdapterManager.PronosticoTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = NutriPllus.NutriBaseDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.UsuarioTableAdapter = Nothing
        '
        'ComidasDataGridView
        '
        Me.ComidasDataGridView.AutoGenerateColumns = False
        Me.ComidasDataGridView.BackgroundColor = System.Drawing.SystemColors.ActiveCaption
        Me.ComidasDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ComidasDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3})
        Me.ComidasDataGridView.DataSource = Me.ComidasBindingSource
        Me.ComidasDataGridView.Location = New System.Drawing.Point(408, 127)
        Me.ComidasDataGridView.Name = "ComidasDataGridView"
        Me.ComidasDataGridView.RowHeadersWidth = 51
        Me.ComidasDataGridView.RowTemplate.Height = 24
        Me.ComidasDataGridView.Size = New System.Drawing.Size(692, 321)
        Me.ComidasDataGridView.TabIndex = 29
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "ID"
        Me.DataGridViewTextBoxColumn1.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 125
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Comida"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Comida"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 125
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Calorias"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Calorias"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 125
        '
        'IDTextBox
        '
        Me.IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ComidasBindingSource, "ID", True))
        Me.IDTextBox.Location = New System.Drawing.Point(778, 474)
        Me.IDTextBox.Name = "IDTextBox"
        Me.IDTextBox.Size = New System.Drawing.Size(67, 22)
        Me.IDTextBox.TabIndex = 30
        '
        'ComidaTextBox
        '
        Me.ComidaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ComidasBindingSource, "Comida", True))
        Me.ComidaTextBox.Location = New System.Drawing.Point(862, 474)
        Me.ComidaTextBox.Name = "ComidaTextBox"
        Me.ComidaTextBox.Size = New System.Drawing.Size(140, 22)
        Me.ComidaTextBox.TabIndex = 32
        '
        'CaloriasTextBox
        '
        Me.CaloriasTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ComidasBindingSource, "Calorias", True))
        Me.CaloriasTextBox.Location = New System.Drawing.Point(1025, 474)
        Me.CaloriasTextBox.Name = "CaloriasTextBox"
        Me.CaloriasTextBox.Size = New System.Drawing.Size(63, 22)
        Me.CaloriasTextBox.TabIndex = 34
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(518, 474)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(106, 49)
        Me.Button7.TabIndex = 35
        Me.Button7.Text = "Nuevo"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(630, 474)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(104, 49)
        Me.Button9.TabIndex = 36
        Me.Button9.Text = "Guardar"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(408, 474)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(104, 49)
        Me.Button10.TabIndex = 37
        Me.Button10.Text = "Borrar"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(404, 87)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(229, 22)
        Me.Label2.TabIndex = 38
        Me.Label2.Text = "Añade comidas a tu listado"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(240, 82)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 23)
        Me.Label3.TabIndex = 29
        Me.Label3.Text = "Nutri-Plus"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1182, 553)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(IDLabel)
        Me.Controls.Add(Me.IDTextBox)
        Me.Controls.Add(ComidaLabel)
        Me.Controls.Add(Me.ComidaTextBox)
        Me.Controls.Add(CaloriasLabel)
        Me.Controls.Add(Me.CaloriasTextBox)
        Me.Controls.Add(Me.ComidasDataGridView)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel5)
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form2"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        CType(Me.NutriBaseDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ComidasBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ComidasDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button6 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label19 As Label
    Friend WithEvents NutriBaseDataSet As NutriBaseDataSet
    Friend WithEvents ComidasBindingSource As BindingSource
    Friend WithEvents ComidasTableAdapter As NutriBaseDataSetTableAdapters.ComidasTableAdapter
    Friend WithEvents TableAdapterManager As NutriBaseDataSetTableAdapters.TableAdapterManager
    Friend WithEvents ComidasDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents IDTextBox As TextBox
    Friend WithEvents ComidaTextBox As TextBox
    Friend WithEvents CaloriasTextBox As TextBox
    Friend WithEvents Button7 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
End Class

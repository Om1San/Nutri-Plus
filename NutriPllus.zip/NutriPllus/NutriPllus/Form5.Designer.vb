﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.NutriBaseDataSet = New NutriPllus.NutriBaseDataSet()
        Me.ComidasBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ComidasTableAdapter = New NutriPllus.NutriBaseDataSetTableAdapters.ComidasTableAdapter()
        Me.TableAdapterManager = New NutriPllus.NutriBaseDataSetTableAdapters.TableAdapterManager()
        Me.EjerciciosTableAdapter = New NutriPllus.NutriBaseDataSetTableAdapters.EjerciciosTableAdapter()
        Me.ComidasDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EjerciciosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EjerciciosDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.ComidasTableAdapter1 = New NutriPllus.NutriBaseDataSetTableAdapters.ComidasTableAdapter()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.UsuarioBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.UsuarioTableAdapter = New NutriPllus.NutriBaseDataSetTableAdapters.UsuarioTableAdapter()
        Me.IDTextBox = New System.Windows.Forms.TextBox()
        Me.NombreTextBox = New System.Windows.Forms.TextBox()
        Me.ApellidoTextBox = New System.Windows.Forms.TextBox()
        Me.SexoTextBox = New System.Windows.Forms.TextBox()
        Me.PesoTextBox = New System.Windows.Forms.TextBox()
        Me.AlturaTextBox = New System.Windows.Forms.TextBox()
        Me.EdadTextBox = New System.Windows.Forms.TextBox()
        Me.Peso_MTextBox = New System.Windows.Forms.TextBox()
        Me.PronosticoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PronosticoTableAdapter = New NutriPllus.NutriBaseDataSetTableAdapters.PronosticoTableAdapter()
        Me.IDTextBox1 = New System.Windows.Forms.TextBox()
        Me.Peso_PerdidoTextBox = New System.Windows.Forms.TextBox()
        Me.Peso_AumentadoTextBox = New System.Windows.Forms.TextBox()
        Me.Total_CalTextBox = New System.Windows.Forms.TextBox()
        Me.FechaDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.PromedioTextBox = New System.Windows.Forms.TextBox()
        Me.Cal_AumentadasTextBox = New System.Windows.Forms.TextBox()
        Me.Cal_QuemadasTextBox = New System.Windows.Forms.TextBox()
        Me.Cal_RestantesTextBox = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        CType(Me.NutriBaseDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ComidasBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ComidasDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EjerciciosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EjerciciosDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UsuarioBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PronosticoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.PaleGreen
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Button6)
        Me.Panel1.Controls.Add(Me.Button8)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Button5)
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Location = New System.Drawing.Point(-42, -16)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(347, 588)
        Me.Panel1.TabIndex = 27
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(240, 82)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(96, 23)
        Me.Label16.TabIndex = 46
        Me.Label16.Text = "Nutri-Plus"
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(54, 328)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(272, 65)
        Me.Button6.TabIndex = 28
        Me.Button6.Text = "Pronostico"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(54, 475)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(157, 78)
        Me.Button8.TabIndex = 8
        Me.Button8.Text = "Comidas"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.NutriPllus.My.Resources.Resources.calories_calculator_2316949
        Me.PictureBox1.Location = New System.Drawing.Point(54, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(91, 81)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(147, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(189, 23)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Contador de Calorias"
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(217, 475)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(105, 78)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "Salir"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(54, 399)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(271, 65)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "Tienda"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(54, 257)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(272, 65)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Recoleccion de Datos"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Gainsboro
        Me.Button2.Location = New System.Drawing.Point(54, 186)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(272, 65)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Ejercicios"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(54, 115)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(272, 65)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Calorias"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.LightCoral
        Me.Panel5.Controls.Add(Me.Label19)
        Me.Panel5.Location = New System.Drawing.Point(-38, -19)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1263, 83)
        Me.Panel5.TabIndex = 28
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(349, 42)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(80, 22)
        Me.Label19.TabIndex = 16
        Me.Label19.Text = "Calorias"
        '
        'NutriBaseDataSet
        '
        Me.NutriBaseDataSet.DataSetName = "NutriBaseDataSet"
        Me.NutriBaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ComidasBindingSource
        '
        Me.ComidasBindingSource.DataMember = "Comidas"
        Me.ComidasBindingSource.DataSource = Me.NutriBaseDataSet
        '
        'ComidasTableAdapter
        '
        Me.ComidasTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ComidasTableAdapter = Me.ComidasTableAdapter
        Me.TableAdapterManager.EjerciciosTableAdapter = Me.EjerciciosTableAdapter
        Me.TableAdapterManager.PronosticoTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = NutriPllus.NutriBaseDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.UsuarioTableAdapter = Nothing
        '
        'EjerciciosTableAdapter
        '
        Me.EjerciciosTableAdapter.ClearBeforeFill = True
        '
        'ComidasDataGridView
        '
        Me.ComidasDataGridView.AllowUserToAddRows = False
        Me.ComidasDataGridView.AllowUserToDeleteRows = False
        Me.ComidasDataGridView.AllowUserToOrderColumns = True
        Me.ComidasDataGridView.AutoGenerateColumns = False
        Me.ComidasDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ComidasDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn1})
        Me.ComidasDataGridView.DataSource = Me.ComidasBindingSource
        Me.ComidasDataGridView.Location = New System.Drawing.Point(349, 196)
        Me.ComidasDataGridView.Name = "ComidasDataGridView"
        Me.ComidasDataGridView.ReadOnly = True
        Me.ComidasDataGridView.RowHeadersWidth = 51
        Me.ComidasDataGridView.RowTemplate.Height = 24
        Me.ComidasDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.ComidasDataGridView.Size = New System.Drawing.Size(238, 181)
        Me.ComidasDataGridView.TabIndex = 29
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Comida"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Comida"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 125
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Calorias"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Calorias"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Visible = False
        Me.DataGridViewTextBoxColumn3.Width = 125
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "ID"
        Me.DataGridViewTextBoxColumn1.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Visible = False
        Me.DataGridViewTextBoxColumn1.Width = 125
        '
        'EjerciciosBindingSource
        '
        Me.EjerciciosBindingSource.DataMember = "Ejercicios"
        Me.EjerciciosBindingSource.DataSource = Me.NutriBaseDataSet
        '
        'EjerciciosDataGridView
        '
        Me.EjerciciosDataGridView.AllowUserToAddRows = False
        Me.EjerciciosDataGridView.AllowUserToDeleteRows = False
        Me.EjerciciosDataGridView.AllowUserToOrderColumns = True
        Me.EjerciciosDataGridView.AutoGenerateColumns = False
        Me.EjerciciosDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.EjerciciosDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7})
        Me.EjerciciosDataGridView.DataSource = Me.EjerciciosBindingSource
        Me.EjerciciosDataGridView.Location = New System.Drawing.Point(887, 196)
        Me.EjerciciosDataGridView.Name = "EjerciciosDataGridView"
        Me.EjerciciosDataGridView.ReadOnly = True
        Me.EjerciciosDataGridView.RowHeadersWidth = 51
        Me.EjerciciosDataGridView.RowTemplate.Height = 24
        Me.EjerciciosDataGridView.Size = New System.Drawing.Size(238, 181)
        Me.EjerciciosDataGridView.TabIndex = 29
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "ID"
        Me.DataGridViewTextBoxColumn4.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Visible = False
        Me.DataGridViewTextBoxColumn4.Width = 125
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "Ejercicio"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Ejercicio"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Width = 125
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "Calorias_Quemadas"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Calorias_Quemadas"
        Me.DataGridViewTextBoxColumn6.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        Me.DataGridViewTextBoxColumn6.Visible = False
        Me.DataGridViewTextBoxColumn6.Width = 125
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "Reps"
        Me.DataGridViewTextBoxColumn7.HeaderText = "Reps"
        Me.DataGridViewTextBoxColumn7.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Visible = False
        Me.DataGridViewTextBoxColumn7.Width = 125
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(361, 173)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 17)
        Me.Label2.TabIndex = 30
        Me.Label2.Text = "Calorias:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(426, 173)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(20, 17)
        Me.Label3.TabIndex = 31
        Me.Label3.Text = "..."
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(899, 173)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(136, 17)
        Me.Label4.TabIndex = 32
        Me.Label4.Text = "Calorias Quemadas:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(1041, 176)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(20, 17)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "..."
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(349, 383)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(206, 51)
        Me.Button7.TabIndex = 34
        Me.Button7.Text = "Añadir"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(902, 383)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(223, 51)
        Me.Button9.TabIndex = 35
        Me.Button9.Text = "Añadir"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(401, 141)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(154, 23)
        Me.Label6.TabIndex = 36
        Me.Label6.Text = "Insertar Comida:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(932, 141)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(166, 23)
        Me.Label7.TabIndex = 37
        Me.Label7.Text = "Insertar Ejercicio:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(585, 459)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(171, 22)
        Me.Label8.TabIndex = 38
        Me.Label8.Text = "Calorias Quemadas:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(831, 396)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(25, 22)
        Me.Label9.TabIndex = 39
        Me.Label9.Text = "..."
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(582, 396)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(185, 22)
        Me.Label10.TabIndex = 40
        Me.Label10.Text = "Calorias Consumidas:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(831, 459)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(25, 22)
        Me.Label11.TabIndex = 41
        Me.Label11.Text = "..."
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(668, 99)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(135, 23)
        Me.Label12.TabIndex = 42
        Me.Label12.Text = "Total Calorias:"
        '
        'ComidasTableAdapter1
        '
        Me.ComidasTableAdapter1.ClearBeforeFill = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(701, 179)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(55, 35)
        Me.Label13.TabIndex = 43
        Me.Label13.Text = "....."
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(701, 293)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(55, 35)
        Me.Label14.TabIndex = 44
        Me.Label14.Text = "....."
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(707, 241)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(50, 35)
        Me.Label15.TabIndex = 45
        Me.Label15.Text = "De"
        '
        'UsuarioBindingSource
        '
        Me.UsuarioBindingSource.DataMember = "Usuario"
        Me.UsuarioBindingSource.DataSource = Me.NutriBaseDataSet
        '
        'UsuarioTableAdapter
        '
        Me.UsuarioTableAdapter.ClearBeforeFill = True
        '
        'IDTextBox
        '
        Me.IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.UsuarioBindingSource, "ID", True))
        Me.IDTextBox.Location = New System.Drawing.Point(1134, 191)
        Me.IDTextBox.Name = "IDTextBox"
        Me.IDTextBox.Size = New System.Drawing.Size(10, 22)
        Me.IDTextBox.TabIndex = 46
        '
        'NombreTextBox
        '
        Me.NombreTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.UsuarioBindingSource, "Nombre", True))
        Me.NombreTextBox.Location = New System.Drawing.Point(1134, 219)
        Me.NombreTextBox.Name = "NombreTextBox"
        Me.NombreTextBox.Size = New System.Drawing.Size(10, 22)
        Me.NombreTextBox.TabIndex = 48
        '
        'ApellidoTextBox
        '
        Me.ApellidoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.UsuarioBindingSource, "Apellido", True))
        Me.ApellidoTextBox.Location = New System.Drawing.Point(1134, 247)
        Me.ApellidoTextBox.Name = "ApellidoTextBox"
        Me.ApellidoTextBox.Size = New System.Drawing.Size(10, 22)
        Me.ApellidoTextBox.TabIndex = 50
        '
        'SexoTextBox
        '
        Me.SexoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.UsuarioBindingSource, "Sexo", True))
        Me.SexoTextBox.Location = New System.Drawing.Point(1134, 275)
        Me.SexoTextBox.Name = "SexoTextBox"
        Me.SexoTextBox.Size = New System.Drawing.Size(10, 22)
        Me.SexoTextBox.TabIndex = 52
        '
        'PesoTextBox
        '
        Me.PesoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.UsuarioBindingSource, "Peso", True))
        Me.PesoTextBox.Location = New System.Drawing.Point(1134, 303)
        Me.PesoTextBox.Name = "PesoTextBox"
        Me.PesoTextBox.Size = New System.Drawing.Size(10, 22)
        Me.PesoTextBox.TabIndex = 54
        '
        'AlturaTextBox
        '
        Me.AlturaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.UsuarioBindingSource, "Altura", True))
        Me.AlturaTextBox.Location = New System.Drawing.Point(1134, 331)
        Me.AlturaTextBox.Name = "AlturaTextBox"
        Me.AlturaTextBox.Size = New System.Drawing.Size(10, 22)
        Me.AlturaTextBox.TabIndex = 56
        '
        'EdadTextBox
        '
        Me.EdadTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.UsuarioBindingSource, "Edad", True))
        Me.EdadTextBox.Location = New System.Drawing.Point(1134, 359)
        Me.EdadTextBox.Name = "EdadTextBox"
        Me.EdadTextBox.Size = New System.Drawing.Size(10, 22)
        Me.EdadTextBox.TabIndex = 58
        '
        'Peso_MTextBox
        '
        Me.Peso_MTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.UsuarioBindingSource, "Peso_M", True))
        Me.Peso_MTextBox.Location = New System.Drawing.Point(1134, 387)
        Me.Peso_MTextBox.Name = "Peso_MTextBox"
        Me.Peso_MTextBox.Size = New System.Drawing.Size(10, 22)
        Me.Peso_MTextBox.TabIndex = 60
        '
        'PronosticoBindingSource
        '
        Me.PronosticoBindingSource.DataMember = "Pronostico"
        Me.PronosticoBindingSource.DataSource = Me.NutriBaseDataSet
        '
        'PronosticoTableAdapter
        '
        Me.PronosticoTableAdapter.ClearBeforeFill = True
        '
        'IDTextBox1
        '
        Me.IDTextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PronosticoBindingSource, "ID", True))
        Me.IDTextBox1.Location = New System.Drawing.Point(1150, 191)
        Me.IDTextBox1.Name = "IDTextBox1"
        Me.IDTextBox1.Size = New System.Drawing.Size(14, 22)
        Me.IDTextBox1.TabIndex = 62
        '
        'Peso_PerdidoTextBox
        '
        Me.Peso_PerdidoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PronosticoBindingSource, "Peso_Perdido", True))
        Me.Peso_PerdidoTextBox.Location = New System.Drawing.Point(1150, 219)
        Me.Peso_PerdidoTextBox.Name = "Peso_PerdidoTextBox"
        Me.Peso_PerdidoTextBox.Size = New System.Drawing.Size(14, 22)
        Me.Peso_PerdidoTextBox.TabIndex = 64
        '
        'Peso_AumentadoTextBox
        '
        Me.Peso_AumentadoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PronosticoBindingSource, "Peso_Aumentado", True))
        Me.Peso_AumentadoTextBox.Location = New System.Drawing.Point(1150, 247)
        Me.Peso_AumentadoTextBox.Name = "Peso_AumentadoTextBox"
        Me.Peso_AumentadoTextBox.Size = New System.Drawing.Size(14, 22)
        Me.Peso_AumentadoTextBox.TabIndex = 66
        '
        'Total_CalTextBox
        '
        Me.Total_CalTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PronosticoBindingSource, "Total_Cal", True))
        Me.Total_CalTextBox.Location = New System.Drawing.Point(1150, 275)
        Me.Total_CalTextBox.Name = "Total_CalTextBox"
        Me.Total_CalTextBox.Size = New System.Drawing.Size(14, 22)
        Me.Total_CalTextBox.TabIndex = 68
        '
        'FechaDateTimePicker
        '
        Me.FechaDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.PronosticoBindingSource, "Fecha", True))
        Me.FechaDateTimePicker.Location = New System.Drawing.Point(1150, 303)
        Me.FechaDateTimePicker.Name = "FechaDateTimePicker"
        Me.FechaDateTimePicker.Size = New System.Drawing.Size(14, 22)
        Me.FechaDateTimePicker.TabIndex = 70
        '
        'PromedioTextBox
        '
        Me.PromedioTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PronosticoBindingSource, "Promedio", True))
        Me.PromedioTextBox.Location = New System.Drawing.Point(1150, 331)
        Me.PromedioTextBox.Name = "PromedioTextBox"
        Me.PromedioTextBox.Size = New System.Drawing.Size(14, 22)
        Me.PromedioTextBox.TabIndex = 72
        '
        'Cal_AumentadasTextBox
        '
        Me.Cal_AumentadasTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PronosticoBindingSource, "Cal_Aumentadas", True))
        Me.Cal_AumentadasTextBox.Location = New System.Drawing.Point(1150, 359)
        Me.Cal_AumentadasTextBox.Name = "Cal_AumentadasTextBox"
        Me.Cal_AumentadasTextBox.Size = New System.Drawing.Size(14, 22)
        Me.Cal_AumentadasTextBox.TabIndex = 74
        '
        'Cal_QuemadasTextBox
        '
        Me.Cal_QuemadasTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PronosticoBindingSource, "Cal_Quemadas", True))
        Me.Cal_QuemadasTextBox.Location = New System.Drawing.Point(1150, 387)
        Me.Cal_QuemadasTextBox.Name = "Cal_QuemadasTextBox"
        Me.Cal_QuemadasTextBox.Size = New System.Drawing.Size(14, 22)
        Me.Cal_QuemadasTextBox.TabIndex = 76
        '
        'Cal_RestantesTextBox
        '
        Me.Cal_RestantesTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PronosticoBindingSource, "Cal_Restantes", True))
        Me.Cal_RestantesTextBox.Location = New System.Drawing.Point(1150, 415)
        Me.Cal_RestantesTextBox.Name = "Cal_RestantesTextBox"
        Me.Cal_RestantesTextBox.Size = New System.Drawing.Size(14, 22)
        Me.Cal_RestantesTextBox.TabIndex = 78
        '
        'Panel2
        '
        Me.Panel2.Location = New System.Drawing.Point(1131, 66)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(203, 563)
        Me.Panel2.TabIndex = 79
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1182, 553)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.IDTextBox1)
        Me.Controls.Add(Me.Peso_PerdidoTextBox)
        Me.Controls.Add(Me.Peso_AumentadoTextBox)
        Me.Controls.Add(Me.Total_CalTextBox)
        Me.Controls.Add(Me.FechaDateTimePicker)
        Me.Controls.Add(Me.PromedioTextBox)
        Me.Controls.Add(Me.Cal_AumentadasTextBox)
        Me.Controls.Add(Me.Cal_QuemadasTextBox)
        Me.Controls.Add(Me.Cal_RestantesTextBox)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.EjerciciosDataGridView)
        Me.Controls.Add(Me.ComidasDataGridView)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.IDTextBox)
        Me.Controls.Add(Me.NombreTextBox)
        Me.Controls.Add(Me.ApellidoTextBox)
        Me.Controls.Add(Me.SexoTextBox)
        Me.Controls.Add(Me.PesoTextBox)
        Me.Controls.Add(Me.AlturaTextBox)
        Me.Controls.Add(Me.EdadTextBox)
        Me.Controls.Add(Me.Peso_MTextBox)
        Me.Name = "Form5"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form5"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        CType(Me.NutriBaseDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ComidasBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ComidasDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EjerciciosBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EjerciciosDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UsuarioBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PronosticoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button6 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label19 As Label
    Friend WithEvents NutriBaseDataSet As NutriBaseDataSet
    Friend WithEvents ComidasBindingSource As BindingSource
    Friend WithEvents ComidasTableAdapter As NutriBaseDataSetTableAdapters.ComidasTableAdapter
    Friend WithEvents TableAdapterManager As NutriBaseDataSetTableAdapters.TableAdapterManager
    Friend WithEvents ComidasDataGridView As DataGridView
    Friend WithEvents EjerciciosTableAdapter As NutriBaseDataSetTableAdapters.EjerciciosTableAdapter
    Friend WithEvents EjerciciosBindingSource As BindingSource
    Friend WithEvents EjerciciosDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Button7 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents ComidasTableAdapter1 As NutriBaseDataSetTableAdapters.ComidasTableAdapter
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents UsuarioBindingSource As BindingSource
    Friend WithEvents UsuarioTableAdapter As NutriBaseDataSetTableAdapters.UsuarioTableAdapter
    Friend WithEvents IDTextBox As TextBox
    Friend WithEvents NombreTextBox As TextBox
    Friend WithEvents ApellidoTextBox As TextBox
    Friend WithEvents SexoTextBox As TextBox
    Friend WithEvents PesoTextBox As TextBox
    Friend WithEvents AlturaTextBox As TextBox
    Friend WithEvents EdadTextBox As TextBox
    Friend WithEvents Peso_MTextBox As TextBox
    Friend WithEvents PronosticoBindingSource As BindingSource
    Friend WithEvents PronosticoTableAdapter As NutriBaseDataSetTableAdapters.PronosticoTableAdapter
    Friend WithEvents IDTextBox1 As TextBox
    Friend WithEvents Peso_PerdidoTextBox As TextBox
    Friend WithEvents Peso_AumentadoTextBox As TextBox
    Friend WithEvents Total_CalTextBox As TextBox
    Friend WithEvents FechaDateTimePicker As DateTimePicker
    Friend WithEvents PromedioTextBox As TextBox
    Friend WithEvents Cal_AumentadasTextBox As TextBox
    Friend WithEvents Cal_QuemadasTextBox As TextBox
    Friend WithEvents Cal_RestantesTextBox As TextBox
    Friend WithEvents Panel2 As Panel
End Class

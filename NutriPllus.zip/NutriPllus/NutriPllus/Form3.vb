﻿Public Class Form3
    Private Sub EjerciciosBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.EjerciciosBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.NutriBaseDataSet)

    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'NutriBaseDataSet.Ejercicios' table. You can move, or remove it, as needed.
        Me.EjerciciosTableAdapter.Fill(Me.NutriBaseDataSet.Ejercicios)

    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Try
            EjerciciosBindingSource.EndEdit()
            EjerciciosTableAdapter.Update(NutriBaseDataSet.Ejercicios)
            MessageBox.Show("Los Datos han sido Guardados")
        Catch ex As Exception
            MessageBox.Show("Error de Guardado")
        End Try
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        EjerciciosBindingSource.AddNew()
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        EjerciciosBindingSource.RemoveCurrent()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Dim form2 As New Form2()
        form2.Show()
        Me.Hide()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        End
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim form4 As New Form4()
        form4.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        System.Diagnostics.Process.Start("http://www.gnc.com")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim form5 As New Form5()
        form5.Show()
        Me.Hide()
    End Sub
End Class